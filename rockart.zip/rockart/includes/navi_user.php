	<table class="navi_table">
		<tr>
			<td><a href="../index.php"> | Etusivulle | </a></td>	
			<td class="navi_login"><a href="../admin/index.php"> | Kirjaudu | </a><a href="../../rockart3/index.php">| Suomen muinaistaideseura | </a></td>
		</tr>
	</table>