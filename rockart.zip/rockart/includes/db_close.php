<?php
mysql_close($yhteys);
?>