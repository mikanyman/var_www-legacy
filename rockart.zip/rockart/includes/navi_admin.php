	<table class="navi_table">
		<tr>
			<td><a href="../admin/index.php"> | Yll�pidon etusivulle | </a></td>
			<td class="navi_login"><a href="../admin/logout.php"> | Kirjaudu ulos| </a></td>
		</tr>
	</table>