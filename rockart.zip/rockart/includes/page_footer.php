<div class="footer">
	<table class="footer_table">
		<tr>
			<td><img src="../includes/images/logo.jpg"></td>
			<td>Suomen muinaistaideseura ry</td>
		</tr>
	</table>
</div>

</div>

</body>
</html>
